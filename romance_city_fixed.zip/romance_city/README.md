# ROMANCE CITY · THE AWAKENING

1. 在 VS Code 打开此文件夹。
2. 使用 Live Server 打开 index.html（或运行 `python -m http.server 8000` 并访问 http://localhost:8000）。
3. Chrome 中点击 ENTER THE EXPERIENCE，允许摄像头。
4. 张开手掌在角色上形成圆形水波并局部显色；握拳进入下一角色。右下角显示 MediaPipe 手部骨架。
5. 鼠标按住拖动也可以揭色；按 F 切换角色；左右箭头切换；数字圆点直接导航。

注意：浏览器需联网加载 MediaPipe 模型与 WASM。角色图来自提供的合照裁切，边缘可能残留背景；建议后续替换成透明 PNG。城堡使用提供的模型照片作为最后一幕。演示版本采用 Canvas 2D 累积揭色遮罩，并非真正的 GLSL 折射 Shader 或 Three.js 3D 场景。
